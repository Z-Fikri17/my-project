<?php
include ("connect.php");
session_start();

// Check if 'emp_id' is set in the GET request
if (isset($_GET["emp_id"])) {
    // Sanitize the input to prevent SQL injection
    $EmpID = mysqli_real_escape_string($conn, $_GET["emp_id"]);

    // Prepare the SQL query to select the employee record
    $sql = "SELECT empbasic.*, attend_daily.* 
            FROM empbasic 
            INNER JOIN attend_daily ON empbasic.EmpID = attend_daily.EmpID 
            WHERE empbasic.EmpID = '$EmpID'";
}
    // Execute the query
    $result = mysqli_query($conn, $sql) or die(mysqli_error($conn));

    // Check if any rows were returned
    if (mysqli_num_rows($result) > 0) {

                // Start the table
                echo "<style> 
                body {
                    font-family: Arial, sans-serif;
                    background-color: #f4f4f4;
                    margin: 20px;
                }
                table {
                    border-collapse: collapse;
                    width: 100%;
                    margin-top: 20px;
                    box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                }
                th, td {
                    border: 1px solid #ddd;
                    padding: 12px;
                    text-align: center;
                }
                th {
                    background-color: #4CAF50;
                    color: white;
                }
                tr:nth-child(even) {
                    background-color: #f2f2f2;
                }
                tr:hover {
                    background-color: #ddd;
                }
                h2 {
                    color: #333;
                }
              </style>";
        echo "<h2>Employee Working Hours</h2>";
        echo "<table>";
        echo "<thead>";
        echo "<tr>";
        echo "<th>EmpID</th>";
        echo "<th>Last Name</th>";
        echo "<th>Date</th>";
        echo "<th>Normal Hours</th>";
        echo "<th>Total Hours Worked</th>";
        echo "<th>Total Overtime Hours</th>";
        echo "</tr>";
        echo "</thead>";
        echo "<tbody>";

                // Output data of each row
                $standard_hours = 8;
                while ($row = mysqli_fetch_assoc($result)) {

               $timezone = new DateTimeZone('Asia/Kuala_Lumpur'); // Set your desired timezone     

               $inTime1 = new DateTime($row["InTime1"], $timezone); // e.g., "2023-10-01 08:00:00"
               $outTime2 = new DateTime($row["OutTime2"], $timezone); // e.g., "2023-10-01 16:00:00"

               // Debugging output
              // echo "InTime1: " . $inTime1->format('Y-m-d H:i:s') . "</br>";
              // echo "OutTime2: " . $outTime2->format('Y-m-d H:i:s') . "</br>";

               // Check if InTime1 is later than OutTime2
if ($inTime1 > $outTime2) {
    // If OutTime2 is meant to be on the next day, adjust accordingly
    $outTime2->modify('+1 day'); // Adjust OutTime2 to the next day

    // Debugging output after modification
   // echo "Adjusted OutTime2: " . $outTime2->format('Y-m-d H:i:s') . "\n";
}

                   // Check if InTime1 is later than OutTime2
                 if ($inTime1 > $outTime2) {
                echo "Error: InTime1 is later than OutTime2. Please check the input times.\n </br>";
               continue; // Skip this iteration
                }

               // Lebih pukul 12am dikira hari esok
               $interval = $inTime1->diff($outTime2);
               // Convert the time strings to timestamps
               // Convert the DateTime objects to timestamps
               $inTime1Timestamp = $inTime1->getTimestamp();
               $outTime2Timestamp = $outTime2->getTimestamp();

               // Check if both timestamps are valid
               if ($inTime1Timestamp !== false && $outTime2Timestamp !== false) {
             // Calculate the total hours worked
               $totalSeconds = $outTime2Timestamp - $inTime1Timestamp; // Total seconds worked
               $totalHours = $totalSeconds / 3600; // Convert seconds to hours

                $standard_hours = 8; 

                // End working hour
                $EndWork = new DateTime(('17:00:00'), $timezone);
                $EndWork2Timestamp = $EndWork->getTimestamp();

            // Calculate the minutes worked
            $minutesWorked = ($totalSeconds % 3600) / 60; // Get remaining minutes after hours

           // Calculate the difference
           $OvertimeSeconds = $outTime2Timestamp - $EndWork2Timestamp;

           $OvertimeHours = $OvertimeSeconds / 3600;

           $totalOvertimeMinutes = ($OvertimeSeconds % 3600) / 60;
          // echo $OvertimeHours . "\r \n";
           
          // $totalOvertimeMinutes = ($OvertimeHours % 3600) / 60;  // Convert seconds to hours

           $NumFormat_OT_Hours = number_format($OvertimeHours, 1);
            
           // Debug: Print the calculated OvertimeHours and totalOvertimeMinutes
    // Determine rounding based on the minutes worked
    if ($minutesWorked >= 15 && $minutesWorked < 45) 
    {
        // Round to 30 minutes
        $roundedHours = floor($totalHours) + 0.5;
    } elseif ($minutesWorked >= 45) {
        // Round to the next hour
        $roundedHours = ceil($totalHours);
    } else {
        // No rounding needed, just take the floor
        $roundedHours = floor($totalHours);
    }
   // $totalOvertimeHours = $totalHours - $standard_hours; // Assuming standard_hours is defined
       // Determine rounding based on the total overtime minutes
       
    if ($totalOvertimeMinutes >= 15  && $totalOvertimeMinutes < 45 ) { // 15 to 45 minutes in hours
    // Round to 30 minutes
    $roundedOvertimeHours = floor($NumFormat_OT_Hours) + 0.5; // Convert back to hours
} else if ($totalOvertimeMinutes >= 45) {
    // Round to the next hourr
    $roundedOvertimeHours = ceil($NumFormat_OT_Hours); // Convert back to hours
} 
 else {
    // No rounding needed, just take the floor
    $roundedOvertimeHours = floor($NumFormat_OT_Hours);
}
// Format to 2 decimal places
//$roundedOvertimeHours = round($roundedOvertimeHours, 2);  

                    echo "<tr>";
                    echo "<td>" . htmlspecialchars($row["EmpID"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["LastName2_c"]) . "</td>";
                    echo "<td>" . htmlspecialchars($row["date"]) . "</td>";
                    echo "<td>" . htmlspecialchars(" 8 Hours") . "</td>";
                    echo "<td>" . htmlspecialchars(round($roundedHours, 2)) . " Hours</td>";                   
                   // echo "<td>" . htmlspecialchars($NumFormat_OT_Hours) . " Hours" . "</td>"; // Output the ro; unded overtime hours
                    echo "<td>" . htmlspecialchars($roundedOvertimeHours) . " Hours</td>"; 
                    echo "</tr>";
                }
                
            } 
                      echo "</tbody>";
                echo "</table>";
          }

// Close the database connection
mysqli_close($conn);
?>