-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 19, 2024 at 01:31 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `working_hour_calculator`
--

-- --------------------------------------------------------

--
-- Table structure for table `attend_daily`
--

CREATE TABLE `attend_daily` (
  `id` int(11) NOT NULL,
  `empid` varchar(50) DEFAULT NULL,
  `date` date DEFAULT NULL,
  `dateOut` date DEFAULT NULL,
  `InTime1` time DEFAULT NULL,
  `OutTime1` time DEFAULT NULL,
  `InTime2` time DEFAULT NULL,
  `OutTime2` time DEFAULT NULL,
  `InTime3` time DEFAULT NULL,
  `OutTime3` time DEFAULT NULL,
  `DayNTD` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `attend_daily`
--

INSERT INTO `attend_daily` (`id`, `empid`, `date`, `dateOut`, `InTime1`, `OutTime1`, `InTime2`, `OutTime2`, `InTime3`, `OutTime3`, `DayNTD`) VALUES
(1100779, 'RC2395', '2020-12-01', '2020-12-01', '07:30:00', '00:00:00', '00:00:00', '18:04:00', NULL, NULL, NULL),
(1100780, 'RS1408', '2020-12-01', '2020-12-01', '07:30:00', '00:00:00', '00:00:00', '03:05:00', NULL, NULL, NULL),
(1100781, 'RS1407', '2020-12-02', '2020-12-21', '07:20:00', '00:00:00', '00:00:00', '03:15:00', NULL, NULL, NULL),
(1100782, 'RC2395', '2020-12-02', NULL, '07:59:00', '00:00:00', '00:00:00', '20:50:00', NULL, NULL, NULL),
(1100783, 'RS1408', '2020-12-02', NULL, '07:51:00', '00:00:00', '00:00:00', '18:16:00', NULL, NULL, NULL),
(1100784, 'RS1407', '2020-12-03', NULL, '07:59:00', '00:00:00', '00:00:00', '18:16:00', NULL, NULL, NULL),
(1100785, 'RC0102', '2020-12-03', NULL, '07:59:00', '00:00:00', '00:00:00', '12:03:00', NULL, NULL, NULL),
(1100786, 'RC0118', '2020-12-03', NULL, '08:00:00', '00:00:00', '00:00:00', '17:00:00', NULL, NULL, NULL),
(1100787, 'RC0122', '2020-12-01', NULL, '07:30:00', '00:00:00', '00:00:00', '18:48:00', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `empbasic`
--

CREATE TABLE `empbasic` (
  `id` int(11) NOT NULL,
  `EmpID` varchar(50) DEFAULT NULL,
  `PerConID` varchar(45) DEFAULT NULL,
  `PerConName` varchar(100) DEFAULT NULL,
  `Firstname` varchar(45) DEFAULT NULL,
  `MiddleInitial` varchar(45) DEFAULT NULL,
  `LastName` varchar(100) DEFAULT NULL,
  `LastName2_c` varchar(300) DEFAULT NULL,
  `ICNo_c` varchar(45) NOT NULL,
  `EmpStatus` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `empbasic`
--

INSERT INTO `empbasic` (`id`, `EmpID`, `PerConID`, `PerConName`, `Firstname`, `MiddleInitial`, `LastName`, `LastName2_c`, `ICNo_c`, `EmpStatus`) VALUES
(3890, 'RS1407', NULL, NULL, 'Nurul Nabilah', NULL, 'Mohamed Lazin', 'Nurul Nabilah binti Mohamed Lazin', '940721-03-5562', 'A'),
(3891, 'RS1408', NULL, NULL, 'Zulaikha', NULL, 'Awang Bakar', 'Zulaikha binti Awang Bakar', '000421-06-0360', 'A'),
(3892, 'RC2395', NULL, NULL, 'AL_SYAHIRDANIE', NULL, 'BIN OTHMAN', 'AL_SYAHIRDANIE BIN OTHMAN', '991209-13-6575', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attend_daily`
--
ALTER TABLE `attend_daily`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `empbasic`
--
ALTER TABLE `empbasic`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attend_daily`
--
ALTER TABLE `attend_daily`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1100788;

--
-- AUTO_INCREMENT for table `empbasic`
--
ALTER TABLE `empbasic`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3893;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
