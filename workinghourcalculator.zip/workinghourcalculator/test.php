if (db_rowcount() > 0) {
	for ($i = 0; $i < db_rowcount(); $i++) {
		$consumable_id = db_get($i, 0); // Get consumable ID
		$qty = db_get($i, 1); // Get consumable quantity

		// Update consumable return_qty
		if (isset($rcvconsumable_qty[$i]) && $rcvconsumable_qty[$i] != "") {
			$sqlUpdate = "UPDATE consumable SET return_qty = " . floatval($rcvconsumable_qty[$i]) . " 
						WHERE id = '" . intval($consumable_id) . "'";
			db_update($sqlUpdate);
			$itemCountConsum++;
		}

		// Fetch all material_bin rows for this `pr_consumable_id`
		$sqlConsumable = "SELECT consumable.partnum,
									partdescription,
									SUM(COALESCE(material_bin.onhandqty, 0)) AS total_onhandqty,
									binnum,
									pr_consumable_id,
									SUM(COALESCE(return_qty, 0)) AS total_return_qty,
									qty
							FROM material_bin 
							INNER JOIN consumable ON consumable.partnum = material_bin.partnum
							WHERE pr_id = '" . intval($_GET['id']) . "' AND pr_consumable_id = " . intval($consumable_id) . "
							GROUP BY consumable.partnum, partdescription, binnum, pr_consumable_id, qty";

		db_select($sqlConsumable);
		$rowCount = db_rowcount();

		for ($j = 0; $j < $rowCount; $j++) {
			// Handle rows here
		}
	}
}
